package com.apollo.repo;

import com.apollo.dataobject.InputObj;
import com.apollo.dataobject.OutputObj;

public interface ICalculateRepo {
	OutputObj add(InputObj a);
}
